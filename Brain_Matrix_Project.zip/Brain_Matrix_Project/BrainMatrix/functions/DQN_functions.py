import torch
import torch.nn.functional as F

def build_dqn_network(input_dim, output_dim):
    """Build the architecture of a simple DQN network."""
    model = torch.nn.Sequential(
        torch.nn.Linear(input_dim, 128),
        torch.nn.ReLU(),
        torch.nn.Linear(128, 128),
        torch.nn.ReLU(),
        torch.nn.Linear(128, output_dim)
    )
    return model

def compute_dqn_loss(predicted_q_values, target_q_values):
    """Compute the loss between predicted and target Q-values."""
    return F.mse_loss(predicted_q_values, target_q_values)

def update_dqn_weights(optimizer, loss):
    """Perform backpropagation to update the weights of the DQN."""
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

def select_action(state, epsilon, model):
    """Select an action using epsilon-greedy policy."""
    if torch.rand(1).item() < epsilon:
        return torch.randint(0, model[-1].out_features, (1,))
    else:
        with torch.no_grad():
            return torch.argmax(model(state)).item()
