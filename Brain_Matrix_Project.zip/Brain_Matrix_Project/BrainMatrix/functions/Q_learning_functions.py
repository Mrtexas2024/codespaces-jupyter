import numpy as np

def initialize_q_table(num_states, num_actions):
    """Initialize the Q-table with zeros."""
    return np.zeros((num_states, num_actions))

def update_q_value(q_table, state, action, reward, next_state, alpha, gamma):
    """Update the Q-value for a given state-action pair using the Bellman equation."""
    best_next_action = np.argmax(q_table[next_state])
    td_target = reward + gamma * q_table[next_state, best_next_action]
    td_error = td_target - q_table[state, action]
    q_table[state, action] += alpha * td_error

def select_q_action(state, q_table, epsilon):
    """Select an action based on an epsilon-greedy policy."""
    if np.random.rand() < epsilon:
        return np.random.choice(len(q_table[state]))
    else:
        return np.argmax(q_table[state])

def get_policy_from_q_table(q_table):
    """Extract the optimal policy from the Q-table."""
    return np.argmax(q_table, axis=1)
