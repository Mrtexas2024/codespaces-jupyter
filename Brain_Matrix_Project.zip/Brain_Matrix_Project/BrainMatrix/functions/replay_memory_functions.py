import random
from collections import deque

class ReplayMemory:
    def __init__(self, capacity):
        self.memory = deque(maxlen=capacity)

    def store_experience(self, state, action, reward, next_state, done):
        """Store a transition (experience) in the memory."""
        self.memory.append((state, action, reward, next_state, done))

    def sample_experiences(self, batch_size):
        """Randomly sample a batch of experiences from memory."""
        return random.sample(self.memory, batch_size)

    def can_sample(self, batch_size):
        """Check if the memory has enough experiences to sample."""
        return len(self.memory) >= batch_size

    def __len__(self):
        return len(self.memory)

def process_experience_batch(experiences):
    """Process a batch of experiences into separate lists for model training."""
    states, actions, rewards, next_states, dones = zip(*experiences)
    return states, actions, rewards, next_states, dones
