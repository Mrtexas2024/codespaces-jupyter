import firebase_admin
from firebase_admin import credentials, storage

def initialize_firebase_storage():
    """Initialize connection to Firebase cloud storage."""
    cred = credentials.Certificate("path/to/firebase-credentials.json")
    firebase_admin.initialize_app(cred, {'storageBucket': 'your-app-id.appspot.com'})
    return storage.bucket()

def upload_model_to_cloud(bucket, local_file_path, cloud_file_path):
    """Upload a trained model file to the cloud storage."""
    blob = bucket.blob(cloud_file_path)
    blob.upload_from_filename(local_file_path)
    print(f"Model uploaded to {cloud_file_path}.")

def download_model_from_cloud(bucket, cloud_file_path, local_file_path):
    """Download a model file from the cloud storage."""
    blob = bucket.blob(cloud_file_path)
    blob.download_to_filename(local_file_path)
    print(f"Model downloaded from {cloud_file_path}.")

def list_files_in_cloud_storage(bucket):
    """List all files stored in the cloud storage."""
    blobs = bucket.list_blobs()
    for blob in blobs:
        print(blob.name)
