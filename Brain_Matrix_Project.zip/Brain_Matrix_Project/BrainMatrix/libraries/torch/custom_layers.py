import torch
import torch.nn as nn

# Example: Custom fully connected layer with a specific initialization
class CustomLinearLayer(nn.Module):
    def __init__(self, input_size, output_size):
        super(CustomLinearLayer, self).__init__()
        self.linear = nn.Linear(input_size, output_size)
        nn.init.kaiming_uniform_(self.linear.weight)  # Custom weight initialization

    def forward(self, x):
        return self.linear(x)
