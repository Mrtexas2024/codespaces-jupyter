# Libraries Directory

This directory contains custom implementations and specific versions of popular libraries such as PyTorch, NumPy, and Firebase.

## torch/
- Custom layers and optimizers designed to work with our BrainMatrix neural network models.
- Includes modifications for faster convergence and better weight initialization.

## numpy/
- Optimized matrix operations and utility functions for high-performance computation.
- Tailored specifically for processing the BrainMatrix dataset.

## firebase/
- Custom Firebase integration for syncing data between local storage and the cloud.
- Includes real-time synchronization for brainwave data and experience replay logs.

Please refer to each module's docstrings for further information on usage.
