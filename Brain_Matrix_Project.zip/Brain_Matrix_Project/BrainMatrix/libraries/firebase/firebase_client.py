import firebase_admin
from firebase_admin import credentials, storage

# Initialize Firebase App with credentials
def initialize_firebase():
    cred = credentials.Certificate("path/to/your/firebase_credentials.json")
    firebase_admin.initialize_app(cred, {
        'storageBucket': 'your-bucket-name.appspot.com'
    })

# Upload a file to Firebase storage
def upload_to_firebase(local_file_path, cloud_file_name):
    bucket = storage.bucket()
    blob = bucket.blob(cloud_file_name)
    blob.upload_from_filename(local_file_path)
    print(f"File {local_file_path} uploaded to {cloud_file_name} in Firebase")
