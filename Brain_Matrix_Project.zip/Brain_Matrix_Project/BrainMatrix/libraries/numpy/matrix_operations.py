import numpy as np

# Example: Custom matrix multiplication with error handling
def custom_matrix_multiply(A, B):
    try:
        return np.dot(A, B)
    except ValueError as e:
        print(f"Matrix multiplication failed: {e}")
        return None
