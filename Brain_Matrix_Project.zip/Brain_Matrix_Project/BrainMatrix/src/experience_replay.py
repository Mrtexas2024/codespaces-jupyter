# experience_replay.py
import random
from collections import deque

class ExperienceReplay:
    def __init__(self, capacity=10000):
        self.memory = deque(maxlen=capacity)

    def store(self, experience):
        """
        Store an experience in memory.
        """
        self.memory.append(experience)

    def sample(self, batch_size):
        """
        Sample a batch of experiences from memory.
        """
        return random.sample(self.memory, batch_size)

    def size(self):
        return len(self.memory)
