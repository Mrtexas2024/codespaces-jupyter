# neuron_cloud_storage.py
import firebase_admin
from firebase_admin import credentials, firestore

class NeuronCloudStorage:
    def __init__(self, config_path):
        cred = credentials.Certificate(config_path)
        firebase_admin.initialize_app(cred)
        self.db = firestore.client()

    def upload_data(self, collection_name, data):
        """
        Upload data to the cloud (e.g., Firebase Firestore).
        """
        self.db.collection(collection_name).add(data)

    def fetch_data(self, collection_name, document_id):
        """
        Fetch specific document from the cloud.
        """
        doc = self.db.collection(collection_name).document(document_id).get()
        if doc.exists:
            return doc.to_dict()
        return None
