# logic_layers.py
class LogicLayers:
    def __init__(self):
        self.layers = []

    def add_layer(self, layer_function):
        """
        Add a logic layer to the system.
        """
        self.layers.append(layer_function)

    def process(self, input_data):
        """
        Process data through each logic layer sequentially.
        """
        output = input_data
        for layer in self.layers:
            output = layer(output)
        return output
