# dqn_agent.py
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

class DQNAgent:
    def __init__(self, state_size, action_size, gamma=0.99, epsilon=1.0, learning_rate=0.001):
        self.state_size = state_size
        self.action_size = action_size
        self.gamma = gamma        # Discount factor
        self.epsilon = epsilon    # Exploration rate
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = learning_rate
        self.memory = []  # Experience replay memory

        self.model = self.build_model()

    def build_model(self):
        """
        Build a simple neural network for DQN.
        """
        model = nn.Sequential(
            nn.Linear(self.state_size, 24),
            nn.ReLU(),
            nn.Linear(24, 24),
            nn.ReLU(),
            nn.Linear(24, self.action_size)
        )
        self.optimizer = optim.Adam(model.parameters(), lr=self.learning_rate)
        return model

    def select_action(self, state):
        """
        Select an action based on an epsilon-greedy policy.
        """
        if np.random.rand() <= self.epsilon:
            return np.random.choice(self.action_size)
        state_tensor = torch.FloatTensor(state)
        q_values = self.model(state_tensor)
        return np.argmax(q_values.detach().numpy())

    def learn(self, state, action, reward, next_state):
        """
        Update the model based on the agent's experience.
        """
        target = reward + self.gamma * torch.max(self.model(torch.FloatTensor(next_state)).detach())
        q_update = self.model(torch.FloatTensor(state))[action]
        loss = (q_update - target) ** 2

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
