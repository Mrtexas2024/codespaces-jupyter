# train_agent.py
from .dqn_agent import DQNAgent

class TrainAgent:
    def __init__(self, environment, agent: DQNAgent):
        self.environment = environment
        self.agent = agent

    def train(self, episodes=1000):
        """
        Train the agent for a specified number of episodes.
        """
        for episode in range(episodes):
            state = self.environment.reset()
            done = False
            while not done:
                action = self.agent.select_action(state)
                next_state, reward, done, _ = self.environment.step(action)
                self.agent.learn(state, action, reward, next_state)
                state = next_state
