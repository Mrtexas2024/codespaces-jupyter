# Pre-Trained Models

## Embedding Model 1 (`embedding_model_1.pth`)
- **Type**: Custom-trained word embedding
- **Trained On**: Text data from BrainMatrix task datasets
- **Purpose**: Converts text inputs into dense vectors for downstream NLP tasks in BrainMatrix.
- **Framework**: PyTorch

## Embedding Model 2 (`embedding_model_2.pth`)
- **Type**: Brainwave signal embedding model
- **Trained On**: EEG signal datasets processed for BrainMatrix's cognitive function models
- **Purpose**: Converts brainwave signals into meaningful feature vectors for further processing in neural networks.
- **Framework**: PyTorch
