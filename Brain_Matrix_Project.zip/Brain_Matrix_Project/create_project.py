import os

# Function to create directory if not exists
def create_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)

# Function to write content into a file
def write_file(filepath, content):
    with open(filepath, 'w') as file:
        file.write(content)

# Base directory for the project
base_dir = "brain_matrix_project"

# Define directories and their corresponding files with content
structure = {
    "sentiment_analysis/scripts": {
        "preprocess_data.py": """import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

def preprocess_data(input_file, output_file):
    df = pd.read_csv(input_file)
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(df['review_text'])
    processed_df = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
    processed_df.to_csv(output_file, index=False)
""",
        "train_model.py": """import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib

def train_sentiment_model(input_file, model_output):
    df = pd.read_csv(input_file)
    X = df.drop(columns=['sentiment'])
    y = df['sentiment']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = LogisticRegression()
    model.fit(X_train, y_train)
    
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    print(f'Model Accuracy: {accuracy}')
    
    joblib.dump(model, model_output)
"""
    },
    "sentiment_analysis/analysis": {
        "sine_wave_plot.py": """import numpy as np
import matplotlib.pyplot as plt

# Generate a sine wave
x = np.linspace(0, 10, 100)
y = np.sin(x)

# Plot the sine wave
plt.plot(x, y)
plt.title("Sine Wave")
plt.xlabel("X Axis")
plt.ylabel("Y Axis")
plt.show()
"""
    },
    "neural_simulation/spice_model": {
        "neural_circuit.sp": """* Simple neural circuit example
V1 in 0 SIN(0 1 50) ; Sine wave input
R1 in out 1k        ; Resistor
C1 out 0 1uF        ; Capacitor
.tran 0 10ms        ; Transient analysis
.end
"""
    },
    "neural_simulation/scripts": {
        "run_spice_simulation.py": """import subprocess

def run_spice_simulation(spice_file, output_file):
    command = f'ngspice -b {spice_file} -o {output_file}'
    subprocess.run(command, shell=True)
""",
        "integrate_simulation.py": """import pandas as pd
import matplotlib.pyplot as plt

def analyze_simulation_results(file):
    data = pd.read_csv(file)
    plt.plot(data['time'], data['voltage'])
    plt.title('Neural Circuit Simulation')
    plt.show()
"""
    },
    "machine_learning/models": {
        "model_training.py": """from keras.models import Sequential
from keras.layers import Dense

def create_model(input_shape):
    model = Sequential()
    model.add(Dense(128, activation='relu', input_shape=(input_shape,)))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model
"""
    },
    "machine_learning/sine_wave_integration": {
        "sine_wave_generator.py": """import numpy as np

def generate_sine_wave(frequency, duration, sampling_rate):
    t = np.linspace(0, duration, int(sampling_rate * duration), endpoint=False)
    return np.sin(2 * np.pi * frequency * t)
"""
    },
    "brainwavegpt/api": {
        "api_handler.py": """import requests

def send_brainwave_data(api_url, data):
    response = requests.post(api_url, json=data)
    return response.json()
"""
    },
    "brainwavegpt/encryption": {
        "secure_transmission.py": """from cryptography.fernet import Fernet

def encrypt_data(data, key):
    fernet = Fernet(key)
    return fernet.encrypt(data)

def decrypt_data(token, key):
    fernet = Fernet(key)
    return fernet.decrypt(token)
"""
    },
    "common": {
        "utils.py": """import yaml

def load_config(config_file):
    with open(config_file, 'r') as f:
        return yaml.safe_load(f)
""",
        "config.yaml": """settings:
  api_url: "https://api.brainmatrix.org/v1/brainwave"
  encryption_key: "my-super-secret-key"
"""
    },
    "common": {
        "README.md": """# BrainMatrix Project
This project is structured to support modular functionality across various domains including:
- **Sentiment Analysis** for text reviews
- **Neural Circuit Simulation** using SPICE
- **Machine Learning** for integrating sine waves and neural networks
- **BrainWaveGPT** for brainwave processing and encryption

Each directory contains code, models, and scripts specific to its domain. Please refer to individual module documentation for usage instructions.
"""
    }
}

# Iterate over the structure and create directories and files
for dir_path, files in structure.items():
    full_dir_path = os.path.join(base_dir, dir_path)
    create_directory(full_dir_path)
    
    for filename, content in files.items():
        file_path = os.path.join(full_dir_path, filename)
        write_file(file_path, content)

print("Directory structure and files created successfully!")
