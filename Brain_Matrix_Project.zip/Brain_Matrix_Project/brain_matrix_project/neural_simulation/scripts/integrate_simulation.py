import pandas as pd
import matplotlib.pyplot as plt

def analyze_simulation_results(file):
    data = pd.read_csv(file)
    plt.plot(data['time'], data['voltage'])
    plt.title('Neural Circuit Simulation')
    plt.show()
