import subprocess

def run_spice_simulation(spice_file, output_file):
    command = f'ngspice -b {spice_file} -o {output_file}'
    subprocess.run(command, shell=True)
