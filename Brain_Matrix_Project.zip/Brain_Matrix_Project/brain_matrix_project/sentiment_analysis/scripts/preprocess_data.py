import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

def preprocess_data(input_file, output_file):
    df = pd.read_csv(input_file)
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(df['review_text'])
    processed_df = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
    processed_df.to_csv(output_file, index=False)
