import numpy as np
import matplotlib.pyplot as plt

# Generate a sine wave
x = np.linspace(0, 10, 100)
y = np.sin(x)

# Plot the sine wave
plt.plot(x, y)
plt.title("Sine Wave")
plt.xlabel("X Axis")
plt.ylabel("Y Axis")
plt.show()
