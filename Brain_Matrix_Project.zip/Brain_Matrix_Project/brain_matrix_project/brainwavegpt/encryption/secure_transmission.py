from cryptography.fernet import Fernet

def encrypt_data(data, key):
    fernet = Fernet(key)
    return fernet.encrypt(data)

def decrypt_data(token, key):
    fernet = Fernet(key)
    return fernet.decrypt(token)
