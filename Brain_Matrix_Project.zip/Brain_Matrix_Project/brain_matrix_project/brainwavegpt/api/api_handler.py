import requests

def send_brainwave_data(api_url, data):
    response = requests.post(api_url, json=data)
    return response.json()
